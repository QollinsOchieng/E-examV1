﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Marks_Entry_full_paper
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.cboecode = New System.Windows.Forms.ComboBox()
        Me.cboeid = New System.Windows.Forms.ComboBox()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.cboename = New System.Windows.Forms.ComboBox()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.cboyear = New System.Windows.Forms.ComboBox()
        Me.cbostream = New System.Windows.Forms.ComboBox()
        Me.cboclass = New System.Windows.Forms.ComboBox()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.dgvStudents = New System.Windows.Forms.DataGridView()
        Me.txtSnum = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.DataEntryPanel2 = New System.Windows.Forms.Panel()
        Me.txtsid = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.geop1 = New System.Windows.Forms.NumericUpDown()
        Me.geop2 = New System.Windows.Forms.NumericUpDown()
        Me.histp2 = New System.Windows.Forms.NumericUpDown()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.histp1 = New System.Windows.Forms.NumericUpDown()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.g5p3 = New System.Windows.Forms.NumericUpDown()
        Me.g5p2 = New System.Windows.Forms.NumericUpDown()
        Me.g5p1 = New System.Windows.Forms.NumericUpDown()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.selg5 = New System.Windows.Forms.ComboBox()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.g4p3 = New System.Windows.Forms.NumericUpDown()
        Me.g4p2 = New System.Windows.Forms.NumericUpDown()
        Me.g4p1 = New System.Windows.Forms.NumericUpDown()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.selg4 = New System.Windows.Forms.ComboBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.relp2 = New System.Windows.Forms.NumericUpDown()
        Me.relp1 = New System.Windows.Forms.NumericUpDown()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.selrelp1 = New System.Windows.Forms.ComboBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.gensci = New System.Windows.Forms.NumericUpDown()
        Me.phycp3 = New System.Windows.Forms.NumericUpDown()
        Me.phycp2 = New System.Windows.Forms.NumericUpDown()
        Me.phycp1 = New System.Windows.Forms.NumericUpDown()
        Me.chemp3 = New System.Windows.Forms.NumericUpDown()
        Me.chemp2 = New System.Windows.Forms.NumericUpDown()
        Me.chemp1 = New System.Windows.Forms.NumericUpDown()
        Me.biop3 = New System.Windows.Forms.NumericUpDown()
        Me.biop2 = New System.Windows.Forms.NumericUpDown()
        Me.biop1 = New System.Windows.Forms.NumericUpDown()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.kslp3 = New System.Windows.Forms.NumericUpDown()
        Me.kslp2 = New System.Windows.Forms.NumericUpDown()
        Me.kslp1 = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.matbp2 = New System.Windows.Forms.NumericUpDown()
        Me.matbp1 = New System.Windows.Forms.NumericUpDown()
        Me.matap2 = New System.Windows.Forms.NumericUpDown()
        Me.matap1 = New System.Windows.Forms.NumericUpDown()
        Me.kisp3 = New System.Windows.Forms.NumericUpDown()
        Me.kisp2 = New System.Windows.Forms.NumericUpDown()
        Me.kisp1 = New System.Windows.Forms.NumericUpDown()
        Me.engp3 = New System.Windows.Forms.NumericUpDown()
        Me.engp2 = New System.Windows.Forms.NumericUpDown()
        Me.engp1 = New System.Windows.Forms.NumericUpDown()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.TXTB = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnNewClass = New System.Windows.Forms.Button()
        Me.txtsname = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtsnumber = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtEdit = New System.Windows.Forms.CheckBox()
        Me.Panel12.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.Panel8.SuspendLayout()
        CType(Me.dgvStudents, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.DataEntryPanel2.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.geop1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.geop2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.histp2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.histp1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox9.SuspendLayout()
        CType(Me.g5p3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.g5p2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.g5p1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox8.SuspendLayout()
        CType(Me.g4p3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.g4p2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.g4p1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox7.SuspendLayout()
        CType(Me.relp2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.relp1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        CType(Me.gensci, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.phycp3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.phycp2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.phycp1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chemp3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chemp2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chemp1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.biop3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.biop2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.biop1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        CType(Me.kslp3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.kslp2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.kslp1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.matbp2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.matbp1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.matap2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.matap1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.kisp3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.kisp2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.kisp1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.engp3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.engp2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.engp1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel11.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel12
        '
        Me.Panel12.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel12.Controls.Add(Me.cboecode)
        Me.Panel12.Controls.Add(Me.cboeid)
        Me.Panel12.Controls.Add(Me.Label59)
        Me.Panel12.Controls.Add(Me.Label60)
        Me.Panel12.Controls.Add(Me.Button8)
        Me.Panel12.Controls.Add(Me.cboename)
        Me.Panel12.Controls.Add(Me.Panel13)
        Me.Panel12.Controls.Add(Me.Label65)
        Me.Panel12.Location = New System.Drawing.Point(210, 54)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(958, 139)
        Me.Panel12.TabIndex = 25
        '
        'cboecode
        '
        Me.cboecode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboecode.FormattingEnabled = True
        Me.cboecode.Location = New System.Drawing.Point(606, 24)
        Me.cboecode.Name = "cboecode"
        Me.cboecode.Size = New System.Drawing.Size(121, 24)
        Me.cboecode.TabIndex = 23
        '
        'cboeid
        '
        Me.cboeid.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboeid.FormattingEnabled = True
        Me.cboeid.Location = New System.Drawing.Point(350, 24)
        Me.cboeid.Name = "cboeid"
        Me.cboeid.Size = New System.Drawing.Size(129, 24)
        Me.cboeid.TabIndex = 21
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(520, 27)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(77, 17)
        Me.Label59.TabIndex = 18
        Me.Label59.Text = "Exam code"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(289, 25)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(55, 17)
        Me.Label60.TabIndex = 17
        Me.Label60.Text = "ExamID"
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(775, 80)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(126, 47)
        Me.Button8.TabIndex = 16
        Me.Button8.Text = "Next"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'cboename
        '
        Me.cboename.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboename.FormattingEnabled = True
        Me.cboename.Location = New System.Drawing.Point(75, 24)
        Me.cboename.Name = "cboename"
        Me.cboename.Size = New System.Drawing.Size(164, 24)
        Me.cboename.TabIndex = 1
        '
        'Panel13
        '
        Me.Panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel13.Controls.Add(Me.cboyear)
        Me.Panel13.Controls.Add(Me.cbostream)
        Me.Panel13.Controls.Add(Me.cboclass)
        Me.Panel13.Controls.Add(Me.Label61)
        Me.Panel13.Controls.Add(Me.Label62)
        Me.Panel13.Controls.Add(Me.Label63)
        Me.Panel13.Location = New System.Drawing.Point(21, 55)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(725, 72)
        Me.Panel13.TabIndex = 15
        '
        'cboyear
        '
        Me.cboyear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboyear.FormattingEnabled = True
        Me.cboyear.Location = New System.Drawing.Point(530, 22)
        Me.cboyear.Name = "cboyear"
        Me.cboyear.Size = New System.Drawing.Size(125, 24)
        Me.cboyear.TabIndex = 5
        '
        'cbostream
        '
        Me.cbostream.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbostream.FormattingEnabled = True
        Me.cbostream.Location = New System.Drawing.Point(298, 22)
        Me.cbostream.Name = "cbostream"
        Me.cbostream.Size = New System.Drawing.Size(145, 24)
        Me.cbostream.TabIndex = 4
        '
        'cboclass
        '
        Me.cboclass.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboclass.FormattingEnabled = True
        Me.cboclass.Items.AddRange(New Object() {"FORM 1", "FORM 2", "FORM 3", "FORM 4"})
        Me.cboclass.Location = New System.Drawing.Point(73, 22)
        Me.cboclass.Name = "cboclass"
        Me.cboclass.Size = New System.Drawing.Size(144, 24)
        Me.cboclass.TabIndex = 3
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(474, 22)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(38, 17)
        Me.Label61.TabIndex = 2
        Me.Label61.Text = "Year"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(239, 22)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(53, 17)
        Me.Label62.TabIndex = 1
        Me.Label62.Text = "Stream"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(15, 25)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(42, 17)
        Me.Label63.TabIndex = 0
        Me.Label63.Text = "Class"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(18, 27)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(42, 17)
        Me.Label65.TabIndex = 0
        Me.Label65.Text = "Exam"
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.Teal
        Me.Panel8.Controls.Add(Me.Label13)
        Me.Panel8.Location = New System.Drawing.Point(3, 3)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(1771, 37)
        Me.Panel8.TabIndex = 26
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label13.Location = New System.Drawing.Point(44, 9)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(323, 25)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "Student entry marks (Full paper)"
        '
        'dgvStudents
        '
        Me.dgvStudents.AllowUserToAddRows = False
        Me.dgvStudents.AllowUserToDeleteRows = False
        Me.dgvStudents.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.dgvStudents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvStudents.Location = New System.Drawing.Point(12, 316)
        Me.dgvStudents.Name = "dgvStudents"
        Me.dgvStudents.ReadOnly = True
        Me.dgvStudents.RowTemplate.Height = 24
        Me.dgvStudents.Size = New System.Drawing.Size(464, 449)
        Me.dgvStudents.TabIndex = 30
        '
        'txtSnum
        '
        Me.txtSnum.Location = New System.Drawing.Point(142, 275)
        Me.txtSnum.Name = "txtSnum"
        Me.txtSnum.Size = New System.Drawing.Size(205, 22)
        Me.txtSnum.TabIndex = 32
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(10, 278)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(109, 17)
        Me.Label14.TabIndex = 31
        Me.Label14.Text = "Student number"
        '
        'DataEntryPanel2
        '
        Me.DataEntryPanel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataEntryPanel2.Controls.Add(Me.txtsid)
        Me.DataEntryPanel2.Controls.Add(Me.Label4)
        Me.DataEntryPanel2.Controls.Add(Me.Panel10)
        Me.DataEntryPanel2.Controls.Add(Me.txtsname)
        Me.DataEntryPanel2.Controls.Add(Me.Label16)
        Me.DataEntryPanel2.Controls.Add(Me.txtsnumber)
        Me.DataEntryPanel2.Controls.Add(Me.Label17)
        Me.DataEntryPanel2.Location = New System.Drawing.Point(498, 207)
        Me.DataEntryPanel2.Name = "DataEntryPanel2"
        Me.DataEntryPanel2.Size = New System.Drawing.Size(1282, 708)
        Me.DataEntryPanel2.TabIndex = 29
        '
        'txtsid
        '
        Me.txtsid.Enabled = False
        Me.txtsid.Location = New System.Drawing.Point(138, 17)
        Me.txtsid.Name = "txtsid"
        Me.txtsid.Size = New System.Drawing.Size(93, 22)
        Me.txtsid.TabIndex = 22
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(21, 17)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(74, 17)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "Student ID"
        '
        'Panel10
        '
        Me.Panel10.Controls.Add(Me.btnUpdate)
        Me.Panel10.Controls.Add(Me.GroupBox1)
        Me.Panel10.Controls.Add(Me.CheckBox4)
        Me.Panel10.Controls.Add(Me.GroupBox9)
        Me.Panel10.Controls.Add(Me.GroupBox8)
        Me.Panel10.Controls.Add(Me.GroupBox7)
        Me.Panel10.Controls.Add(Me.GroupBox6)
        Me.Panel10.Controls.Add(Me.GroupBox5)
        Me.Panel10.Controls.Add(Me.Panel11)
        Me.Panel10.Location = New System.Drawing.Point(15, 56)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(1244, 636)
        Me.Panel10.TabIndex = 20
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(755, 563)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(75, 49)
        Me.btnUpdate.TabIndex = 92
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label31)
        Me.GroupBox1.Controls.Add(Me.Label58)
        Me.GroupBox1.Controls.Add(Me.geop1)
        Me.GroupBox1.Controls.Add(Me.geop2)
        Me.GroupBox1.Controls.Add(Me.histp2)
        Me.GroupBox1.Controls.Add(Me.Label48)
        Me.GroupBox1.Controls.Add(Me.histp1)
        Me.GroupBox1.Controls.Add(Me.Label49)
        Me.GroupBox1.Location = New System.Drawing.Point(755, 13)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(450, 100)
        Me.GroupBox1.TabIndex = 91
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Humanities"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(23, 29)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(60, 17)
        Me.Label31.TabIndex = 83
        Me.Label31.Text = "GEO P1"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(26, 66)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(60, 17)
        Me.Label58.TabIndex = 30
        Me.Label58.Text = "GEO P2"
        '
        'geop1
        '
        Me.geop1.Location = New System.Drawing.Point(96, 26)
        Me.geop1.Name = "geop1"
        Me.geop1.Size = New System.Drawing.Size(108, 22)
        Me.geop1.TabIndex = 84
        '
        'geop2
        '
        Me.geop2.Location = New System.Drawing.Point(96, 66)
        Me.geop2.Name = "geop2"
        Me.geop2.Size = New System.Drawing.Size(108, 22)
        Me.geop2.TabIndex = 85
        '
        'histp2
        '
        Me.histp2.Location = New System.Drawing.Point(275, 65)
        Me.histp2.Name = "histp2"
        Me.histp2.Size = New System.Drawing.Size(108, 22)
        Me.histp2.TabIndex = 87
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(211, 26)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(51, 17)
        Me.Label48.TabIndex = 29
        Me.Label48.Text = "HIS P1"
        '
        'histp1
        '
        Me.histp1.Location = New System.Drawing.Point(275, 24)
        Me.histp1.Name = "histp1"
        Me.histp1.Size = New System.Drawing.Size(108, 22)
        Me.histp1.TabIndex = 86
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(211, 67)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(51, 17)
        Me.Label49.TabIndex = 28
        Me.Label49.Text = "HIS P2"
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Location = New System.Drawing.Point(605, 472)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(132, 21)
        Me.CheckBox4.TabIndex = 90
        Me.CheckBox4.Text = "Select Religion?"
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.Label7)
        Me.GroupBox9.Controls.Add(Me.g5p3)
        Me.GroupBox9.Controls.Add(Me.g5p2)
        Me.GroupBox9.Controls.Add(Me.g5p1)
        Me.GroupBox9.Controls.Add(Me.Label64)
        Me.GroupBox9.Controls.Add(Me.Label57)
        Me.GroupBox9.Controls.Add(Me.Label56)
        Me.GroupBox9.Controls.Add(Me.selg5)
        Me.GroupBox9.Location = New System.Drawing.Point(755, 344)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(461, 200)
        Me.GroupBox9.TabIndex = 89
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "GROUP5"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(170, 72)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(25, 17)
        Me.Label7.TabIndex = 82
        Me.Label7.Text = "P1"
        '
        'g5p3
        '
        Me.g5p3.Location = New System.Drawing.Point(214, 151)
        Me.g5p3.Name = "g5p3"
        Me.g5p3.Size = New System.Drawing.Size(112, 22)
        Me.g5p3.TabIndex = 81
        '
        'g5p2
        '
        Me.g5p2.Location = New System.Drawing.Point(214, 111)
        Me.g5p2.Name = "g5p2"
        Me.g5p2.Size = New System.Drawing.Size(112, 22)
        Me.g5p2.TabIndex = 80
        '
        'g5p1
        '
        Me.g5p1.Location = New System.Drawing.Point(214, 70)
        Me.g5p1.Name = "g5p1"
        Me.g5p1.Size = New System.Drawing.Size(112, 22)
        Me.g5p1.TabIndex = 79
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(48, 35)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(128, 17)
        Me.Label64.TabIndex = 31
        Me.Label64.Text = "GROUP 5 SELECT"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(170, 156)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(25, 17)
        Me.Label57.TabIndex = 38
        Me.Label57.Text = "P3"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(170, 113)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(25, 17)
        Me.Label56.TabIndex = 39
        Me.Label56.Text = "P2"
        '
        'selg5
        '
        Me.selg5.FormattingEnabled = True
        Me.selg5.Items.AddRange(New Object() {"FRENCH", "GERM", "ARAB", "MUSIC", "BUS"})
        Me.selg5.Location = New System.Drawing.Point(196, 30)
        Me.selg5.Name = "selg5"
        Me.selg5.Size = New System.Drawing.Size(216, 24)
        Me.selg5.TabIndex = 77
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.Label6)
        Me.GroupBox8.Controls.Add(Me.g4p3)
        Me.GroupBox8.Controls.Add(Me.g4p2)
        Me.GroupBox8.Controls.Add(Me.g4p1)
        Me.GroupBox8.Controls.Add(Me.Label54)
        Me.GroupBox8.Controls.Add(Me.Label53)
        Me.GroupBox8.Controls.Add(Me.Label52)
        Me.GroupBox8.Controls.Add(Me.selg4)
        Me.GroupBox8.Location = New System.Drawing.Point(755, 121)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(450, 205)
        Me.GroupBox8.TabIndex = 88
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "GROUP4"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(151, 71)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(25, 17)
        Me.Label6.TabIndex = 79
        Me.Label6.Text = "P1"
        '
        'g4p3
        '
        Me.g4p3.Location = New System.Drawing.Point(196, 152)
        Me.g4p3.Name = "g4p3"
        Me.g4p3.Size = New System.Drawing.Size(112, 22)
        Me.g4p3.TabIndex = 78
        '
        'g4p2
        '
        Me.g4p2.Location = New System.Drawing.Point(196, 111)
        Me.g4p2.Name = "g4p2"
        Me.g4p2.Size = New System.Drawing.Size(112, 22)
        Me.g4p2.TabIndex = 77
        '
        'g4p1
        '
        Me.g4p1.Location = New System.Drawing.Point(196, 66)
        Me.g4p1.Name = "g4p1"
        Me.g4p1.Size = New System.Drawing.Size(112, 22)
        Me.g4p1.TabIndex = 76
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(151, 157)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(25, 17)
        Me.Label54.TabIndex = 23
        Me.Label54.Text = "P3"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(151, 115)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(25, 17)
        Me.Label53.TabIndex = 24
        Me.Label53.Text = "P2"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(31, 27)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(128, 17)
        Me.Label52.TabIndex = 25
        Me.Label52.Text = "GROUP 4 SELECT"
        '
        'selg4
        '
        Me.selg4.FormattingEnabled = True
        Me.selg4.Items.AddRange(New Object() {"HOME SCI", "ART", "AGRIC", "COMPUTER", "WOODWORK", "METALWORK", "BUILDCONSTR", "POWERMECH", "ELEC", "DD", "AVIATION"})
        Me.selg4.Location = New System.Drawing.Point(173, 21)
        Me.selg4.Name = "selg4"
        Me.selg4.Size = New System.Drawing.Size(216, 24)
        Me.selg4.TabIndex = 74
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.Label5)
        Me.GroupBox7.Controls.Add(Me.relp2)
        Me.GroupBox7.Controls.Add(Me.relp1)
        Me.GroupBox7.Controls.Add(Me.Label51)
        Me.GroupBox7.Controls.Add(Me.Label50)
        Me.GroupBox7.Controls.Add(Me.selrelp1)
        Me.GroupBox7.Location = New System.Drawing.Point(370, 495)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(367, 135)
        Me.GroupBox7.TabIndex = 82
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "RELIGION"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(111, 61)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(25, 17)
        Me.Label5.TabIndex = 76
        Me.Label5.Text = "P1"
        '
        'relp2
        '
        Me.relp2.Location = New System.Drawing.Point(146, 98)
        Me.relp2.Name = "relp2"
        Me.relp2.Size = New System.Drawing.Size(112, 22)
        Me.relp2.TabIndex = 75
        '
        'relp1
        '
        Me.relp1.Location = New System.Drawing.Point(144, 59)
        Me.relp1.Name = "relp1"
        Me.relp1.Size = New System.Drawing.Size(112, 22)
        Me.relp1.TabIndex = 74
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(108, 100)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(25, 17)
        Me.Label51.TabIndex = 26
        Me.Label51.Text = "P2"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(60, 24)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(73, 17)
        Me.Label50.TabIndex = 27
        Me.Label50.Text = "RELIGION"
        '
        'selrelp1
        '
        Me.selrelp1.FormattingEnabled = True
        Me.selrelp1.Items.AddRange(New Object() {"CRE"})
        Me.selrelp1.Location = New System.Drawing.Point(149, 21)
        Me.selrelp1.Name = "selrelp1"
        Me.selrelp1.Size = New System.Drawing.Size(201, 24)
        Me.selrelp1.TabIndex = 72
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.CheckBox3)
        Me.GroupBox6.Controls.Add(Me.gensci)
        Me.GroupBox6.Controls.Add(Me.phycp3)
        Me.GroupBox6.Controls.Add(Me.phycp2)
        Me.GroupBox6.Controls.Add(Me.phycp1)
        Me.GroupBox6.Controls.Add(Me.chemp3)
        Me.GroupBox6.Controls.Add(Me.chemp2)
        Me.GroupBox6.Controls.Add(Me.chemp1)
        Me.GroupBox6.Controls.Add(Me.biop3)
        Me.GroupBox6.Controls.Add(Me.biop2)
        Me.GroupBox6.Controls.Add(Me.biop1)
        Me.GroupBox6.Controls.Add(Me.Label38)
        Me.GroupBox6.Controls.Add(Me.Label45)
        Me.GroupBox6.Controls.Add(Me.Label44)
        Me.GroupBox6.Controls.Add(Me.Label43)
        Me.GroupBox6.Controls.Add(Me.Label42)
        Me.GroupBox6.Controls.Add(Me.Label41)
        Me.GroupBox6.Controls.Add(Me.Label40)
        Me.GroupBox6.Controls.Add(Me.Label39)
        Me.GroupBox6.Controls.Add(Me.Label55)
        Me.GroupBox6.Controls.Add(Me.Label47)
        Me.GroupBox6.Location = New System.Drawing.Point(370, 15)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(322, 433)
        Me.GroupBox6.TabIndex = 81
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "GROUP2"
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Location = New System.Drawing.Point(236, 390)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(52, 21)
        Me.CheckBox3.TabIndex = 32
        Me.CheckBox3.Text = "chk"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'gensci
        '
        Me.gensci.Location = New System.Drawing.Point(106, 390)
        Me.gensci.Name = "gensci"
        Me.gensci.Size = New System.Drawing.Size(106, 22)
        Me.gensci.TabIndex = 40
        '
        'phycp3
        '
        Me.phycp3.Location = New System.Drawing.Point(111, 344)
        Me.phycp3.Maximum = New Decimal(New Integer() {40, 0, 0, 0})
        Me.phycp3.Name = "phycp3"
        Me.phycp3.Size = New System.Drawing.Size(106, 22)
        Me.phycp3.TabIndex = 39
        '
        'phycp2
        '
        Me.phycp2.Location = New System.Drawing.Point(111, 308)
        Me.phycp2.Maximum = New Decimal(New Integer() {80, 0, 0, 0})
        Me.phycp2.Name = "phycp2"
        Me.phycp2.Size = New System.Drawing.Size(106, 22)
        Me.phycp2.TabIndex = 38
        '
        'phycp1
        '
        Me.phycp1.Location = New System.Drawing.Point(111, 272)
        Me.phycp1.Maximum = New Decimal(New Integer() {80, 0, 0, 0})
        Me.phycp1.Name = "phycp1"
        Me.phycp1.Size = New System.Drawing.Size(106, 22)
        Me.phycp1.TabIndex = 37
        '
        'chemp3
        '
        Me.chemp3.Location = New System.Drawing.Point(111, 228)
        Me.chemp3.Maximum = New Decimal(New Integer() {40, 0, 0, 0})
        Me.chemp3.Name = "chemp3"
        Me.chemp3.Size = New System.Drawing.Size(106, 22)
        Me.chemp3.TabIndex = 36
        '
        'chemp2
        '
        Me.chemp2.Location = New System.Drawing.Point(111, 191)
        Me.chemp2.Maximum = New Decimal(New Integer() {80, 0, 0, 0})
        Me.chemp2.Name = "chemp2"
        Me.chemp2.Size = New System.Drawing.Size(106, 22)
        Me.chemp2.TabIndex = 35
        '
        'chemp1
        '
        Me.chemp1.Location = New System.Drawing.Point(110, 153)
        Me.chemp1.Maximum = New Decimal(New Integer() {80, 0, 0, 0})
        Me.chemp1.Name = "chemp1"
        Me.chemp1.Size = New System.Drawing.Size(106, 22)
        Me.chemp1.TabIndex = 34
        '
        'biop3
        '
        Me.biop3.Location = New System.Drawing.Point(107, 105)
        Me.biop3.Maximum = New Decimal(New Integer() {40, 0, 0, 0})
        Me.biop3.Name = "biop3"
        Me.biop3.Size = New System.Drawing.Size(106, 22)
        Me.biop3.TabIndex = 33
        '
        'biop2
        '
        Me.biop2.Location = New System.Drawing.Point(107, 68)
        Me.biop2.Maximum = New Decimal(New Integer() {80, 0, 0, 0})
        Me.biop2.Name = "biop2"
        Me.biop2.Size = New System.Drawing.Size(106, 22)
        Me.biop2.TabIndex = 32
        '
        'biop1
        '
        Me.biop1.Location = New System.Drawing.Point(107, 31)
        Me.biop1.Maximum = New Decimal(New Integer() {80, 0, 0, 0})
        Me.biop1.Name = "biop1"
        Me.biop1.Size = New System.Drawing.Size(106, 22)
        Me.biop1.TabIndex = 31
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(24, 36)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(82, 17)
        Me.Label38.TabIndex = 21
        Me.Label38.Text = "BIO P1 (80)"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(10, 310)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(96, 17)
        Me.Label45.TabIndex = 14
        Me.Label45.Text = "PHYC P2 (80)"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(10, 274)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(96, 17)
        Me.Label44.TabIndex = 15
        Me.Label44.Text = "PHYC P1 (80)"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(13, 230)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(98, 17)
        Me.Label43.TabIndex = 16
        Me.Label43.Text = "CHEM P3 (40)"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(13, 193)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(98, 17)
        Me.Label42.TabIndex = 17
        Me.Label42.Text = "CHEM P2 (80)"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(13, 158)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(98, 17)
        Me.Label41.TabIndex = 18
        Me.Label41.Text = "CHEM P1 (80)"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(20, 107)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(82, 17)
        Me.Label40.TabIndex = 19
        Me.Label40.Text = "BIO P3 (40)"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(22, 72)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(82, 17)
        Me.Label39.TabIndex = 20
        Me.Label39.Text = "BIO P2 (80)"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(9, 344)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(96, 17)
        Me.Label55.TabIndex = 22
        Me.Label55.Text = "PHYC P3 (40)"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(36, 389)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(59, 17)
        Me.Label47.TabIndex = 30
        Me.Label47.Text = "GENSCI"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.CheckBox2)
        Me.GroupBox5.Controls.Add(Me.CheckBox1)
        Me.GroupBox5.Controls.Add(Me.kslp3)
        Me.GroupBox5.Controls.Add(Me.kslp2)
        Me.GroupBox5.Controls.Add(Me.kslp1)
        Me.GroupBox5.Controls.Add(Me.Label1)
        Me.GroupBox5.Controls.Add(Me.Label2)
        Me.GroupBox5.Controls.Add(Me.Label3)
        Me.GroupBox5.Controls.Add(Me.matbp2)
        Me.GroupBox5.Controls.Add(Me.matbp1)
        Me.GroupBox5.Controls.Add(Me.matap2)
        Me.GroupBox5.Controls.Add(Me.matap1)
        Me.GroupBox5.Controls.Add(Me.kisp3)
        Me.GroupBox5.Controls.Add(Me.kisp2)
        Me.GroupBox5.Controls.Add(Me.kisp1)
        Me.GroupBox5.Controls.Add(Me.engp3)
        Me.GroupBox5.Controls.Add(Me.engp2)
        Me.GroupBox5.Controls.Add(Me.engp1)
        Me.GroupBox5.Controls.Add(Me.Label15)
        Me.GroupBox5.Controls.Add(Me.Label30)
        Me.GroupBox5.Controls.Add(Me.TXTB)
        Me.GroupBox5.Controls.Add(Me.Label32)
        Me.GroupBox5.Controls.Add(Me.Label33)
        Me.GroupBox5.Controls.Add(Me.Label34)
        Me.GroupBox5.Controls.Add(Me.Label35)
        Me.GroupBox5.Controls.Add(Me.Label36)
        Me.GroupBox5.Controls.Add(Me.Label37)
        Me.GroupBox5.Controls.Add(Me.Label46)
        Me.GroupBox5.Location = New System.Drawing.Point(9, 15)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(308, 587)
        Me.GroupBox5.TabIndex = 80
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "GROUP1"
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(238, 507)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(52, 21)
        Me.CheckBox2.TabIndex = 31
        Me.CheckBox2.Text = "chk"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(6, 172)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(52, 21)
        Me.CheckBox1.TabIndex = 30
        Me.CheckBox1.Text = "chk"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'kslp3
        '
        Me.kslp3.Location = New System.Drawing.Point(149, 364)
        Me.kslp3.Maximum = New Decimal(New Integer() {40, 0, 0, 0})
        Me.kslp3.Name = "kslp3"
        Me.kslp3.Size = New System.Drawing.Size(79, 22)
        Me.kslp3.TabIndex = 29
        '
        'kslp2
        '
        Me.kslp2.Location = New System.Drawing.Point(149, 329)
        Me.kslp2.Maximum = New Decimal(New Integer() {25, 0, 0, 0})
        Me.kslp2.Name = "kslp2"
        Me.kslp2.Size = New System.Drawing.Size(79, 22)
        Me.kslp2.TabIndex = 28
        '
        'kslp1
        '
        Me.kslp1.Location = New System.Drawing.Point(149, 292)
        Me.kslp1.Maximum = New Decimal(New Integer() {35, 0, 0, 0})
        Me.kslp1.Name = "kslp1"
        Me.kslp1.Size = New System.Drawing.Size(79, 22)
        Me.kslp1.TabIndex = 27
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(55, 362)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(85, 17)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = "KSL P3 (40)"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(55, 329)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(85, 17)
        Me.Label2.TabIndex = 25
        Me.Label2.Text = "KSL P2 (25)"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(55, 294)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(85, 17)
        Me.Label3.TabIndex = 26
        Me.Label3.Text = "KSL P1 (35)"
        '
        'matbp2
        '
        Me.matbp2.Location = New System.Drawing.Point(133, 549)
        Me.matbp2.Name = "matbp2"
        Me.matbp2.Size = New System.Drawing.Size(98, 22)
        Me.matbp2.TabIndex = 23
        '
        'matbp1
        '
        Me.matbp1.Location = New System.Drawing.Point(131, 507)
        Me.matbp1.Name = "matbp1"
        Me.matbp1.Size = New System.Drawing.Size(98, 22)
        Me.matbp1.TabIndex = 22
        '
        'matap2
        '
        Me.matap2.Location = New System.Drawing.Point(130, 446)
        Me.matap2.Name = "matap2"
        Me.matap2.Size = New System.Drawing.Size(98, 22)
        Me.matap2.TabIndex = 21
        '
        'matap1
        '
        Me.matap1.Location = New System.Drawing.Point(130, 411)
        Me.matap1.Name = "matap1"
        Me.matap1.Size = New System.Drawing.Size(98, 22)
        Me.matap1.TabIndex = 20
        '
        'kisp3
        '
        Me.kisp3.Enabled = False
        Me.kisp3.Location = New System.Drawing.Point(143, 244)
        Me.kisp3.Maximum = New Decimal(New Integer() {80, 0, 0, 0})
        Me.kisp3.Name = "kisp3"
        Me.kisp3.Size = New System.Drawing.Size(98, 22)
        Me.kisp3.TabIndex = 19
        '
        'kisp2
        '
        Me.kisp2.Enabled = False
        Me.kisp2.Location = New System.Drawing.Point(143, 208)
        Me.kisp2.Maximum = New Decimal(New Integer() {80, 0, 0, 0})
        Me.kisp2.Name = "kisp2"
        Me.kisp2.Size = New System.Drawing.Size(98, 22)
        Me.kisp2.TabIndex = 18
        '
        'kisp1
        '
        Me.kisp1.Enabled = False
        Me.kisp1.Location = New System.Drawing.Point(143, 172)
        Me.kisp1.Maximum = New Decimal(New Integer() {40, 0, 0, 0})
        Me.kisp1.Name = "kisp1"
        Me.kisp1.Size = New System.Drawing.Size(98, 22)
        Me.kisp1.TabIndex = 17
        '
        'engp3
        '
        Me.engp3.Location = New System.Drawing.Point(142, 109)
        Me.engp3.Maximum = New Decimal(New Integer() {60, 0, 0, 0})
        Me.engp3.Name = "engp3"
        Me.engp3.Size = New System.Drawing.Size(98, 22)
        Me.engp3.TabIndex = 16
        '
        'engp2
        '
        Me.engp2.Location = New System.Drawing.Point(142, 67)
        Me.engp2.Maximum = New Decimal(New Integer() {80, 0, 0, 0})
        Me.engp2.Name = "engp2"
        Me.engp2.Size = New System.Drawing.Size(98, 22)
        Me.engp2.TabIndex = 15
        '
        'engp1
        '
        Me.engp1.Location = New System.Drawing.Point(142, 31)
        Me.engp1.Maximum = New Decimal(New Integer() {60, 0, 0, 0})
        Me.engp1.Name = "engp1"
        Me.engp1.Size = New System.Drawing.Size(98, 22)
        Me.engp1.TabIndex = 14
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(46, 33)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(89, 17)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "ENG P1 (60)"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(48, 512)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(77, 17)
        Me.Label30.TabIndex = 5
        Me.Label30.Text = "MAT(B) P1"
        '
        'TXTB
        '
        Me.TXTB.AutoSize = True
        Me.TXTB.Location = New System.Drawing.Point(48, 451)
        Me.TXTB.Name = "TXTB"
        Me.TXTB.Size = New System.Drawing.Size(77, 17)
        Me.TXTB.TabIndex = 6
        Me.TXTB.Text = "MAT(A) P2"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(49, 413)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(77, 17)
        Me.Label32.TabIndex = 7
        Me.Label32.Text = "MAT(A) P1"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(60, 246)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(80, 17)
        Me.Label33.TabIndex = 8
        Me.Label33.Text = "KIS P3 (80)"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(63, 208)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(80, 17)
        Me.Label34.TabIndex = 9
        Me.Label34.Text = "KIS P2 (80)"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(63, 173)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(80, 17)
        Me.Label35.TabIndex = 10
        Me.Label35.Text = "KIS P1 (40)"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(46, 111)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(89, 17)
        Me.Label36.TabIndex = 11
        Me.Label36.Text = "ENG P3 (60)"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(46, 73)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(89, 17)
        Me.Label37.TabIndex = 12
        Me.Label37.Text = "ENG P2 (80)"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(48, 551)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(77, 17)
        Me.Label46.TabIndex = 13
        Me.Label46.Text = "MAT(B) P2"
        '
        'Panel11
        '
        Me.Panel11.Controls.Add(Me.btnSave)
        Me.Panel11.Controls.Add(Me.btnExit)
        Me.Panel11.Controls.Add(Me.btnNewClass)
        Me.Panel11.Location = New System.Drawing.Point(840, 565)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(376, 49)
        Me.Panel11.TabIndex = 4
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(8, 5)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(107, 42)
        Me.btnSave.TabIndex = 2
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(273, 5)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(92, 42)
        Me.btnExit.TabIndex = 3
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnNewClass
        '
        Me.btnNewClass.Location = New System.Drawing.Point(141, 5)
        Me.btnNewClass.Name = "btnNewClass"
        Me.btnNewClass.Size = New System.Drawing.Size(108, 42)
        Me.btnNewClass.TabIndex = 1
        Me.btnNewClass.Text = "New Class"
        Me.btnNewClass.UseVisualStyleBackColor = True
        '
        'txtsname
        '
        Me.txtsname.Enabled = False
        Me.txtsname.Location = New System.Drawing.Point(723, 14)
        Me.txtsname.Name = "txtsname"
        Me.txtsname.Size = New System.Drawing.Size(192, 22)
        Me.txtsname.TabIndex = 19
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(611, 14)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(96, 17)
        Me.Label16.TabIndex = 17
        Me.Label16.Text = "Student name"
        '
        'txtsnumber
        '
        Me.txtsnumber.Enabled = False
        Me.txtsnumber.Location = New System.Drawing.Point(421, 17)
        Me.txtsnumber.Name = "txtsnumber"
        Me.txtsnumber.Size = New System.Drawing.Size(163, 22)
        Me.txtsnumber.TabIndex = 16
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(291, 17)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(111, 17)
        Me.Label17.TabIndex = 15
        Me.Label17.Text = "Student Number"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.SteelBlue
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Location = New System.Drawing.Point(13, 223)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(463, 40)
        Me.Panel2.TabIndex = 33
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label10.Location = New System.Drawing.Point(14, 10)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(185, 20)
        Me.Label10.TabIndex = 31
        Me.Label10.Text = "Search student here!"
        '
        'txtEdit
        '
        Me.txtEdit.AutoSize = True
        Me.txtEdit.Location = New System.Drawing.Point(1355, 172)
        Me.txtEdit.Name = "txtEdit"
        Me.txtEdit.Size = New System.Drawing.Size(149, 21)
        Me.txtEdit.TabIndex = 34
        Me.txtEdit.Text = "Edit Student marks"
        Me.txtEdit.UseVisualStyleBackColor = True
        '
        'Marks_Entry_full_paper
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(1812, 928)
        Me.Controls.Add(Me.txtEdit)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.dgvStudents)
        Me.Controls.Add(Me.Panel12)
        Me.Controls.Add(Me.txtSnum)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.DataEntryPanel2)
        Me.Controls.Add(Me.Panel8)
        Me.Name = "Marks_Entry_full_paper"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "Marks_Entry_full_paper"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        CType(Me.dgvStudents, System.ComponentModel.ISupportInitialize).EndInit()
        Me.DataEntryPanel2.ResumeLayout(False)
        Me.DataEntryPanel2.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.geop1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.geop2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.histp2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.histp1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        CType(Me.g5p3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.g5p2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.g5p1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        CType(Me.g4p3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.g4p2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.g4p1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        CType(Me.relp2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.relp1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        CType(Me.gensci, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.phycp3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.phycp2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.phycp1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chemp3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chemp2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chemp1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.biop3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.biop2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.biop1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        CType(Me.kslp3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.kslp2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.kslp1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.matbp2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.matbp1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.matap2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.matap1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.kisp3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.kisp2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.kisp1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.engp3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.engp2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.engp1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel11.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel12 As System.Windows.Forms.Panel
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents cboename As System.Windows.Forms.ComboBox
    Friend WithEvents Panel13 As System.Windows.Forms.Panel
    Friend WithEvents cboyear As System.Windows.Forms.ComboBox
    Friend WithEvents cbostream As System.Windows.Forms.ComboBox
    Friend WithEvents cboclass As System.Windows.Forms.ComboBox
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents dgvStudents As System.Windows.Forms.DataGridView
    Friend WithEvents txtSnum As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents DataEntryPanel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents selg5 As System.Windows.Forms.ComboBox
    Friend WithEvents histp2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents histp1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents geop2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents geop1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents selrelp1 As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents gensci As System.Windows.Forms.NumericUpDown
    Friend WithEvents phycp3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents phycp2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents phycp1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents chemp3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents chemp2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents chemp1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents biop3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents biop2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents biop1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents matbp2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents matbp1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents matap2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents matap1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents kisp3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents kisp2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents kisp1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents engp3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents engp2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents engp1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents TXTB As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Panel11 As System.Windows.Forms.Panel
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnNewClass As System.Windows.Forms.Button
    Friend WithEvents txtsname As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtsnumber As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents cboeid As System.Windows.Forms.ComboBox
    Friend WithEvents g5p3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents g5p2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents g5p1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents relp2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents relp1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents kslp3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents kslp2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents kslp1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cboecode As System.Windows.Forms.ComboBox
    Friend WithEvents txtsid As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents g4p3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents g4p2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents g4p1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents selg4 As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox4 As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtEdit As System.Windows.Forms.CheckBox
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
End Class
