﻿Public Class Termly_report

    

    Private Sub Termly_report_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        CRclass = ""
        CRclsyear = 0
        CRstream = ""
        CRetype = ""
        cboetype.SelectedIndex = 0
        cbostream.Enabled = False
        cboclass.Enabled = False
        Button1.Enabled = False
        'For i As Int16 = 2000 To Today.Year Step 1
        '    Me.cboyear.Items.Add(i)
        'Next (i)
        If cboetype.Text = "Normal" Then
            fill_combo(cboclass, "select distinct Class FROM [dbo].[Termly_Student_marks] ")
            fill_combo(cbostream, "select distinct Stream FROM [dbo].[Termly_Student_marks]")
            fill_combo(cboyear, "select distinct class_year FROM [dbo].[Termly_Student_marks]")

        Else
            fill_combo(cboclass, "select distinct Class FROM [dbo].[Termly_Student_marks_fp] ")
            fill_combo(cbostream, "select distinct Stream FROM [dbo].[Termly_Student_marks_fp]")
            fill_combo(cboyear, "select distinct class_year FROM [dbo].[Termly_Student_marks_fp]")

        End If
    End Sub

    Private Sub btnview_Click(sender As System.Object, e As System.EventArgs) Handles btnview.Click
        If cboetype.Text = "Normal" Then
           
            If cboyear.Text <> "" And (cboclass.Text <> "" Or cbostream.Text <> "") And cboTerm.Text <> "" Then
                If chkclass.Checked = True Then
                    fill_grid(dgvReport, "select * from [dbo].[Termly_Student_marks] where Class='" + cboclass.Text + "' " &
                     "and class_year='" + cboyear.Text + "' and Term='" + cboTerm.Text + "' order by AVERAGE DESC")
                    CRTclass = cboclass.Text
                    CRTclsyear = cboyear.Text
                    CRTetype = cboetype.Text
                    CRTstream = ""
                    CRTterm = cboTerm.Text
                    Button1.Enabled = True
                    MsgBox("Search complete!")
                Else
                    fill_grid(dgvReport, "select * from [dbo].[Termly_Student_marks] where Class='" + cboclass.Text + "' " &
                     "and Stream='" + cbostream.Text + "' and class_year='" + cboyear.Text + "' and Term='" + cboTerm.Text + "' order by AVERAGE DESC")
                    CRTclass = cboclass.Text
                    CRTclsyear = cboyear.Text
                    CRTetype = cboetype.Text
                    CRTstream = cbostream.Text
                    CRTterm = cboTerm.Text
                    Button1.Enabled = True
                    MsgBox("Search complete!")
                End If

            Else
                MsgBox("One or more fields is blank!")
                Button1.Enabled = False
            End If
        Else
           
            If cboyear.Text <> "" And (cboclass.Text <> "" Or cbostream.Text <> "") And cboTerm.Text <> "" Then
                If chkstream.Checked = True Then
                    fill_grid(dgvReport, "select * from [dbo].[Termly_Student_marks_fp] where Class='" + cboclass.Text + "' " &
                     "and Stream='" + cbostream.Text + "' and class_year='" + cboyear.Text + "' and Term='" + cboTerm.Text + "' order by AVERAGE DESC")
                    CRTclass = cboclass.Text
                    CRTclsyear = cboyear.Text
                    CRTetype = cboetype.Text
                    CRTstream = cbostream.Text
                    CRTterm = cboTerm.Text
                    Button1.Enabled = True
                    MsgBox("Search complete!")
                Else
                    fill_grid(dgvReport, "select * from [dbo].[Termly_Student_marks_fp] where Class='" + cboclass.Text + "' " &
                     "and class_year='" + cboyear.Text + "' and Term='" + cboTerm.Text + "' order by AVERAGE DESC")
                    CRTclass = cboclass.Text
                    CRTclsyear = cboyear.Text
                    CRTetype = cboetype.Text
                    CRTterm = cboTerm.Text
                    CRTstream = ""
                    Button1.Enabled = True
                    MsgBox("Search complete!")
                End If

            Else
                MsgBox("One or more fields is blank!")
                Button1.Enabled = False
            End If
        End If
        


    End Sub

    Private Sub Label1_Click(sender As System.Object, e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub cboetype_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cboetype.SelectedIndexChanged
        cboclass.Text = ""
        cbostream.Text = ""
        cboyear.Text = ""
        If cboetype.Text = "Normal" Then
            fill_combo(cboclass, "select distinct Class FROM [dbo].[Termly_Student_marks] ")
            fill_combo(cbostream, "select distinct Stream FROM [dbo].[Termly_Student_marks]")
            fill_combo(cboyear, "select distinct class_year FROM [dbo].[Termly_Student_marks]")

        Else
            fill_combo(cboclass, "select distinct Class FROM [dbo].[Termly_Student_marks_fp] ")
            fill_combo(cbostream, "select distinct Stream FROM [dbo].[Termly_Student_marks_fp]")
            fill_combo(cboyear, "select distinct class_year FROM [dbo].[Termly_Student_marks_fp]")

        End If
    End Sub

  
    Private Sub chkstream_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkstream.CheckedChanged
        If chkstream.Checked = True Then
            chkclass.Checked = False
            cbostream.Enabled = True
            cboclass.Enabled = True
        Else
            cbostream.Enabled = False
            cbostream.SelectedIndex = -1
            cboclass.Enabled = True
            cboclass.SelectedIndex = -1
        End If
    End Sub

    Private Sub chkclass_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkclass.CheckedChanged
        If chkclass.Checked = True Then
            chkstream.Checked = False
            cbostream.Enabled = False
            cbostream.SelectedIndex = -1
            cboclass.Enabled = True
        Else
            cbostream.Enabled = True
            ' cbostream.SelectedIndex = -1
            cboclass.Enabled = False
            cboclass.SelectedIndex = -1
        End If
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Form1.ShowDialog()
    End Sub
End Class