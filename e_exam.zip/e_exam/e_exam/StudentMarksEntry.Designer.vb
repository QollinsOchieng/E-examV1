﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MarksEntry_Normal
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.topPanel = New System.Windows.Forms.Panel()
        Me.cboecode = New System.Windows.Forms.ComboBox()
        Me.cboeid = New System.Windows.Forms.ComboBox()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.cboename = New System.Windows.Forms.ComboBox()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.cboyear = New System.Windows.Forms.ComboBox()
        Me.cbostream = New System.Windows.Forms.ComboBox()
        Me.cboclass = New System.Windows.Forms.ComboBox()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.dgvStudents = New System.Windows.Forms.DataGridView()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtSnum = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.DataEntryPanel = New System.Windows.Forms.Panel()
        Me.txtsid = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.artd = New System.Windows.Forms.NumericUpDown()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.hsci = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.comp = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.bus = New System.Windows.Forms.NumericUpDown()
        Me.agric = New System.Windows.Forms.NumericUpDown()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.rel = New System.Windows.Forms.NumericUpDown()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.geo = New System.Windows.Forms.NumericUpDown()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.hist = New System.Windows.Forms.NumericUpDown()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.sel_rel = New System.Windows.Forms.ComboBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chkgensci = New System.Windows.Forms.CheckBox()
        Me.gensci = New System.Windows.Forms.NumericUpDown()
        Me.phyc = New System.Windows.Forms.NumericUpDown()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.chem = New System.Windows.Forms.NumericUpDown()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.bio = New System.Windows.Forms.NumericUpDown()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkkis = New System.Windows.Forms.CheckBox()
        Me.ksl = New System.Windows.Forms.NumericUpDown()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.kis = New System.Windows.Forms.NumericUpDown()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.mat = New System.Windows.Forms.NumericUpDown()
        Me.eng = New System.Windows.Forms.NumericUpDown()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.BtnExit = New System.Windows.Forms.Button()
        Me.btnNewClass = New System.Windows.Forms.Button()
        Me.txtsname = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtsnumber = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.txtEdit = New System.Windows.Forms.CheckBox()
        Me.topPanel.SuspendLayout()
        Me.Panel13.SuspendLayout()
        CType(Me.dgvStudents, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.DataEntryPanel.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.artd, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.hsci, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.comp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.agric, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.rel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.geo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.hist, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.gensci, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.phyc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bio, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.ksl, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.kis, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mat, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.eng, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel7.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'topPanel
        '
        Me.topPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.topPanel.Controls.Add(Me.cboecode)
        Me.topPanel.Controls.Add(Me.cboeid)
        Me.topPanel.Controls.Add(Me.Label59)
        Me.topPanel.Controls.Add(Me.Label60)
        Me.topPanel.Controls.Add(Me.Button8)
        Me.topPanel.Controls.Add(Me.cboename)
        Me.topPanel.Controls.Add(Me.Panel13)
        Me.topPanel.Controls.Add(Me.Label65)
        Me.topPanel.Location = New System.Drawing.Point(285, 64)
        Me.topPanel.Name = "topPanel"
        Me.topPanel.Size = New System.Drawing.Size(936, 156)
        Me.topPanel.TabIndex = 30
        '
        'cboecode
        '
        Me.cboecode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboecode.FormattingEnabled = True
        Me.cboecode.Location = New System.Drawing.Point(618, 22)
        Me.cboecode.Name = "cboecode"
        Me.cboecode.Size = New System.Drawing.Size(121, 24)
        Me.cboecode.TabIndex = 22
        '
        'cboeid
        '
        Me.cboeid.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboeid.FormattingEnabled = True
        Me.cboeid.Location = New System.Drawing.Point(363, 22)
        Me.cboeid.Name = "cboeid"
        Me.cboeid.Size = New System.Drawing.Size(121, 24)
        Me.cboeid.TabIndex = 21
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(532, 27)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(77, 17)
        Me.Label59.TabIndex = 18
        Me.Label59.Text = "Exam code"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(302, 25)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(55, 17)
        Me.Label60.TabIndex = 17
        Me.Label60.Text = "ExamID"
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(765, 94)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(126, 47)
        Me.Button8.TabIndex = 16
        Me.Button8.Text = "Next"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'cboename
        '
        Me.cboename.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboename.FormattingEnabled = True
        Me.cboename.Location = New System.Drawing.Point(75, 24)
        Me.cboename.Name = "cboename"
        Me.cboename.Size = New System.Drawing.Size(199, 24)
        Me.cboename.TabIndex = 1
        '
        'Panel13
        '
        Me.Panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel13.Controls.Add(Me.cboyear)
        Me.Panel13.Controls.Add(Me.cbostream)
        Me.Panel13.Controls.Add(Me.cboclass)
        Me.Panel13.Controls.Add(Me.Label61)
        Me.Panel13.Controls.Add(Me.Label62)
        Me.Panel13.Controls.Add(Me.Label63)
        Me.Panel13.Location = New System.Drawing.Point(21, 69)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(725, 72)
        Me.Panel13.TabIndex = 15
        '
        'cboyear
        '
        Me.cboyear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboyear.FormattingEnabled = True
        Me.cboyear.Location = New System.Drawing.Point(530, 22)
        Me.cboyear.Name = "cboyear"
        Me.cboyear.Size = New System.Drawing.Size(125, 24)
        Me.cboyear.TabIndex = 5
        '
        'cbostream
        '
        Me.cbostream.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbostream.FormattingEnabled = True
        Me.cbostream.Location = New System.Drawing.Point(298, 22)
        Me.cbostream.Name = "cbostream"
        Me.cbostream.Size = New System.Drawing.Size(145, 24)
        Me.cbostream.TabIndex = 4
        '
        'cboclass
        '
        Me.cboclass.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboclass.FormattingEnabled = True
        Me.cboclass.Items.AddRange(New Object() {"FORM 1", "FORM 2", "FORM 3", "FORM 4"})
        Me.cboclass.Location = New System.Drawing.Point(73, 22)
        Me.cboclass.Name = "cboclass"
        Me.cboclass.Size = New System.Drawing.Size(144, 24)
        Me.cboclass.TabIndex = 3
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(474, 22)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(38, 17)
        Me.Label61.TabIndex = 2
        Me.Label61.Text = "Year"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(239, 22)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(53, 17)
        Me.Label62.TabIndex = 1
        Me.Label62.Text = "Stream"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(15, 25)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(42, 17)
        Me.Label63.TabIndex = 0
        Me.Label63.Text = "Class"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(18, 27)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(42, 17)
        Me.Label65.TabIndex = 0
        Me.Label65.Text = "Exam"
        '
        'dgvStudents
        '
        Me.dgvStudents.AllowUserToAddRows = False
        Me.dgvStudents.AllowUserToDeleteRows = False
        Me.dgvStudents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvStudents.Location = New System.Drawing.Point(31, 325)
        Me.dgvStudents.Name = "dgvStudents"
        Me.dgvStudents.ReadOnly = True
        Me.dgvStudents.RowTemplate.Height = 24
        Me.dgvStudents.Size = New System.Drawing.Size(528, 412)
        Me.dgvStudents.TabIndex = 27
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Teal
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Location = New System.Drawing.Point(7, 9)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1888, 37)
        Me.Panel1.TabIndex = 25
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(36, 6)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(295, 25)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Student entry marks (Normal)"
        '
        'txtSnum
        '
        Me.txtSnum.Location = New System.Drawing.Point(158, 293)
        Me.txtSnum.Name = "txtSnum"
        Me.txtSnum.Size = New System.Drawing.Size(205, 22)
        Me.txtSnum.TabIndex = 29
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(28, 293)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(109, 17)
        Me.Label5.TabIndex = 28
        Me.Label5.Text = "Student number"
        '
        'DataEntryPanel
        '
        Me.DataEntryPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataEntryPanel.Controls.Add(Me.txtsid)
        Me.DataEntryPanel.Controls.Add(Me.Label12)
        Me.DataEntryPanel.Controls.Add(Me.Panel4)
        Me.DataEntryPanel.Controls.Add(Me.txtsname)
        Me.DataEntryPanel.Controls.Add(Me.Label7)
        Me.DataEntryPanel.Controls.Add(Me.txtsnumber)
        Me.DataEntryPanel.Controls.Add(Me.Label6)
        Me.DataEntryPanel.Location = New System.Drawing.Point(590, 245)
        Me.DataEntryPanel.Name = "DataEntryPanel"
        Me.DataEntryPanel.Size = New System.Drawing.Size(1228, 540)
        Me.DataEntryPanel.TabIndex = 26
        '
        'txtsid
        '
        Me.txtsid.Enabled = False
        Me.txtsid.Location = New System.Drawing.Point(128, 36)
        Me.txtsid.Name = "txtsid"
        Me.txtsid.Size = New System.Drawing.Size(100, 22)
        Me.txtsid.TabIndex = 22
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(48, 39)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(74, 17)
        Me.Label12.TabIndex = 21
        Me.Label12.Text = "Student ID"
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.GroupBox4)
        Me.Panel4.Controls.Add(Me.GroupBox3)
        Me.Panel4.Controls.Add(Me.GroupBox2)
        Me.Panel4.Controls.Add(Me.GroupBox1)
        Me.Panel4.Controls.Add(Me.Label28)
        Me.Panel4.Controls.Add(Me.Panel7)
        Me.Panel4.Location = New System.Drawing.Point(16, 83)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1191, 437)
        Me.Panel4.TabIndex = 20
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.artd)
        Me.GroupBox4.Controls.Add(Me.Label9)
        Me.GroupBox4.Controls.Add(Me.hsci)
        Me.GroupBox4.Controls.Add(Me.Label3)
        Me.GroupBox4.Controls.Add(Me.comp)
        Me.GroupBox4.Controls.Add(Me.Label1)
        Me.GroupBox4.Controls.Add(Me.bus)
        Me.GroupBox4.Controls.Add(Me.agric)
        Me.GroupBox4.Controls.Add(Me.Label27)
        Me.GroupBox4.Controls.Add(Me.Label29)
        Me.GroupBox4.Location = New System.Drawing.Point(864, 28)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(295, 338)
        Me.GroupBox4.TabIndex = 43
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "COMBINED GRP 4 AND 5"
        '
        'artd
        '
        Me.artd.Location = New System.Drawing.Point(167, 203)
        Me.artd.Name = "artd"
        Me.artd.Size = New System.Drawing.Size(104, 22)
        Me.artd.TabIndex = 47
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(49, 203)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(92, 17)
        Me.Label9.TabIndex = 48
        Me.Label9.Text = "ART DESIGN"
        '
        'hsci
        '
        Me.hsci.Location = New System.Drawing.Point(166, 145)
        Me.hsci.Name = "hsci"
        Me.hsci.Size = New System.Drawing.Size(104, 22)
        Me.hsci.TabIndex = 44
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(67, 145)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(74, 17)
        Me.Label3.TabIndex = 45
        Me.Label3.Text = "HOME SCI"
        '
        'comp
        '
        Me.comp.Location = New System.Drawing.Point(166, 88)
        Me.comp.Name = "comp"
        Me.comp.Size = New System.Drawing.Size(104, 22)
        Me.comp.TabIndex = 41
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(93, 88)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 17)
        Me.Label1.TabIndex = 42
        Me.Label1.Text = "COMP"
        '
        'bus
        '
        Me.bus.Location = New System.Drawing.Point(167, 268)
        Me.bus.Name = "bus"
        Me.bus.Size = New System.Drawing.Size(104, 22)
        Me.bus.TabIndex = 40
        '
        'agric
        '
        Me.agric.Location = New System.Drawing.Point(166, 39)
        Me.agric.Name = "agric"
        Me.agric.Size = New System.Drawing.Size(104, 22)
        Me.agric.TabIndex = 11
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(93, 39)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(50, 17)
        Me.Label27.TabIndex = 36
        Me.Label27.Text = "AGRIC"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(105, 270)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(36, 17)
        Me.Label29.TabIndex = 38
        Me.Label29.Text = "BUS"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.rel)
        Me.GroupBox3.Controls.Add(Me.Label26)
        Me.GroupBox3.Controls.Add(Me.geo)
        Me.GroupBox3.Controls.Add(Me.Label24)
        Me.GroupBox3.Controls.Add(Me.hist)
        Me.GroupBox3.Controls.Add(Me.Label25)
        Me.GroupBox3.Controls.Add(Me.sel_rel)
        Me.GroupBox3.Location = New System.Drawing.Point(592, 23)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(249, 252)
        Me.GroupBox3.TabIndex = 42
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "GROUP3"
        '
        'rel
        '
        Me.rel.Location = New System.Drawing.Point(139, 155)
        Me.rel.Name = "rel"
        Me.rel.Size = New System.Drawing.Size(104, 22)
        Me.rel.TabIndex = 13
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(95, 86)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(39, 17)
        Me.Label26.TabIndex = 14
        Me.Label26.Text = "GEO"
        '
        'geo
        '
        Me.geo.Location = New System.Drawing.Point(139, 85)
        Me.geo.Name = "geo"
        Me.geo.Size = New System.Drawing.Size(104, 22)
        Me.geo.TabIndex = 12
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(95, 28)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(39, 17)
        Me.Label24.TabIndex = 12
        Me.Label24.Text = "HIST"
        '
        'hist
        '
        Me.hist.Location = New System.Drawing.Point(139, 26)
        Me.hist.Name = "hist"
        Me.hist.Size = New System.Drawing.Size(104, 22)
        Me.hist.TabIndex = 11
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(51, 135)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(83, 17)
        Me.Label25.TabIndex = 13
        Me.Label25.Text = "(RELIGION)"
        '
        'sel_rel
        '
        Me.sel_rel.FormattingEnabled = True
        Me.sel_rel.Items.AddRange(New Object() {"CRE"})
        Me.sel_rel.Location = New System.Drawing.Point(13, 155)
        Me.sel_rel.Name = "sel_rel"
        Me.sel_rel.Size = New System.Drawing.Size(121, 24)
        Me.sel_rel.TabIndex = 35
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chkgensci)
        Me.GroupBox2.Controls.Add(Me.gensci)
        Me.GroupBox2.Controls.Add(Me.phyc)
        Me.GroupBox2.Controls.Add(Me.Label21)
        Me.GroupBox2.Controls.Add(Me.chem)
        Me.GroupBox2.Controls.Add(Me.Label20)
        Me.GroupBox2.Controls.Add(Me.bio)
        Me.GroupBox2.Controls.Add(Me.Label22)
        Me.GroupBox2.Controls.Add(Me.Label23)
        Me.GroupBox2.Location = New System.Drawing.Point(312, 18)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(265, 257)
        Me.GroupBox2.TabIndex = 41
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "GROUP2"
        '
        'chkgensci
        '
        Me.chkgensci.AutoSize = True
        Me.chkgensci.Location = New System.Drawing.Point(98, 184)
        Me.chkgensci.Name = "chkgensci"
        Me.chkgensci.Size = New System.Drawing.Size(141, 21)
        Me.chkgensci.TabIndex = 15
        Me.chkgensci.Text = "General science?"
        Me.chkgensci.UseVisualStyleBackColor = True
        '
        'gensci
        '
        Me.gensci.Enabled = False
        Me.gensci.Location = New System.Drawing.Point(98, 208)
        Me.gensci.Name = "gensci"
        Me.gensci.Size = New System.Drawing.Size(104, 22)
        Me.gensci.TabIndex = 14
        '
        'phyc
        '
        Me.phyc.Location = New System.Drawing.Point(94, 127)
        Me.phyc.Name = "phyc"
        Me.phyc.Size = New System.Drawing.Size(104, 22)
        Me.phyc.TabIndex = 13
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(21, 81)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(47, 17)
        Me.Label21.TabIndex = 9
        Me.Label21.Text = "CHEM"
        '
        'chem
        '
        Me.chem.Location = New System.Drawing.Point(94, 79)
        Me.chem.Name = "chem"
        Me.chem.Size = New System.Drawing.Size(104, 22)
        Me.chem.TabIndex = 12
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(37, 33)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(31, 17)
        Me.Label20.TabIndex = 8
        Me.Label20.Text = "BIO"
        '
        'bio
        '
        Me.bio.Location = New System.Drawing.Point(94, 28)
        Me.bio.Name = "bio"
        Me.bio.Size = New System.Drawing.Size(104, 22)
        Me.bio.TabIndex = 11
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(23, 132)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(45, 17)
        Me.Label22.TabIndex = 10
        Me.Label22.Text = "PHYC"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(13, 210)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(59, 17)
        Me.Label23.TabIndex = 11
        Me.Label23.Text = "GENSCI"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkkis)
        Me.GroupBox1.Controls.Add(Me.ksl)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.kis)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.mat)
        Me.GroupBox1.Controls.Add(Me.eng)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Location = New System.Drawing.Point(20, 18)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(261, 257)
        Me.GroupBox1.TabIndex = 40
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GROUP 1"
        '
        'chkkis
        '
        Me.chkkis.AutoSize = True
        Me.chkkis.Location = New System.Drawing.Point(24, 99)
        Me.chkkis.Name = "chkkis"
        Me.chkkis.Size = New System.Drawing.Size(52, 21)
        Me.chkkis.TabIndex = 15
        Me.chkkis.Text = "chk"
        Me.chkkis.UseVisualStyleBackColor = True
        '
        'ksl
        '
        Me.ksl.Location = New System.Drawing.Point(133, 150)
        Me.ksl.Name = "ksl"
        Me.ksl.Size = New System.Drawing.Size(104, 22)
        Me.ksl.TabIndex = 14
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(73, 150)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(34, 17)
        Me.Label11.TabIndex = 13
        Me.Label11.Text = "KSL"
        '
        'kis
        '
        Me.kis.Location = New System.Drawing.Point(132, 98)
        Me.kis.Name = "kis"
        Me.kis.Size = New System.Drawing.Size(104, 22)
        Me.kis.TabIndex = 12
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(82, 100)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 17)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "KIS"
        '
        'mat
        '
        Me.mat.Location = New System.Drawing.Point(133, 213)
        Me.mat.Name = "mat"
        Me.mat.Size = New System.Drawing.Size(104, 22)
        Me.mat.TabIndex = 10
        '
        'eng
        '
        Me.eng.Location = New System.Drawing.Point(133, 44)
        Me.eng.Name = "eng"
        Me.eng.Size = New System.Drawing.Size(104, 22)
        Me.eng.TabIndex = 8
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(73, 44)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(38, 17)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "ENG"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(73, 213)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(37, 17)
        Me.Label19.TabIndex = 7
        Me.Label19.Text = "MAT"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(893, 168)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(0, 17)
        Me.Label28.TabIndex = 16
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.btnUpdate)
        Me.Panel7.Controls.Add(Me.btnSave)
        Me.Panel7.Controls.Add(Me.BtnExit)
        Me.Panel7.Controls.Add(Me.btnNewClass)
        Me.Panel7.Location = New System.Drawing.Point(237, 328)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(558, 72)
        Me.Panel7.TabIndex = 4
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(153, 15)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(120, 42)
        Me.btnUpdate.TabIndex = 4
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(27, 15)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(107, 42)
        Me.btnSave.TabIndex = 2
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'BtnExit
        '
        Me.BtnExit.Location = New System.Drawing.Point(422, 15)
        Me.BtnExit.Name = "BtnExit"
        Me.BtnExit.Size = New System.Drawing.Size(92, 42)
        Me.BtnExit.TabIndex = 3
        Me.BtnExit.Text = "Exit"
        Me.BtnExit.UseVisualStyleBackColor = True
        '
        'btnNewClass
        '
        Me.btnNewClass.Location = New System.Drawing.Point(290, 15)
        Me.btnNewClass.Name = "btnNewClass"
        Me.btnNewClass.Size = New System.Drawing.Size(108, 42)
        Me.btnNewClass.TabIndex = 1
        Me.btnNewClass.Text = "New Class"
        Me.btnNewClass.UseVisualStyleBackColor = True
        '
        'txtsname
        '
        Me.txtsname.Enabled = False
        Me.txtsname.Location = New System.Drawing.Point(667, 39)
        Me.txtsname.Name = "txtsname"
        Me.txtsname.Size = New System.Drawing.Size(192, 22)
        Me.txtsname.TabIndex = 19
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(555, 39)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(96, 17)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "Student name"
        '
        'txtsnumber
        '
        Me.txtsnumber.Enabled = False
        Me.txtsnumber.Location = New System.Drawing.Point(370, 39)
        Me.txtsnumber.Name = "txtsnumber"
        Me.txtsnumber.Size = New System.Drawing.Size(145, 22)
        Me.txtsnumber.TabIndex = 16
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(240, 39)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(111, 17)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "Student Number"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label10.Location = New System.Drawing.Point(14, 10)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(185, 20)
        Me.Label10.TabIndex = 31
        Me.Label10.Text = "Search student here!"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.SteelBlue
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Location = New System.Drawing.Point(31, 245)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(528, 40)
        Me.Panel2.TabIndex = 32
        '
        'txtEdit
        '
        Me.txtEdit.AutoSize = True
        Me.txtEdit.Location = New System.Drawing.Point(1616, 218)
        Me.txtEdit.Name = "txtEdit"
        Me.txtEdit.Size = New System.Drawing.Size(183, 21)
        Me.txtEdit.TabIndex = 33
        Me.txtEdit.Text = "EDIT STUDENT MARKS"
        Me.txtEdit.UseVisualStyleBackColor = True
        '
        'MarksEntry_Normal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(1914, 816)
        Me.Controls.Add(Me.txtEdit)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.topPanel)
        Me.Controls.Add(Me.dgvStudents)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.txtSnum)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.DataEntryPanel)
        Me.Name = "MarksEntry_Normal"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MarksEntry_Normal"
        Me.topPanel.ResumeLayout(False)
        Me.topPanel.PerformLayout()
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout()
        CType(Me.dgvStudents, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.DataEntryPanel.ResumeLayout(False)
        Me.DataEntryPanel.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.artd, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.hsci, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.comp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.agric, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.rel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.geo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.hist, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.gensci, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.phyc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bio, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.ksl, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.kis, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mat, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.eng, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel7.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents topPanel As System.Windows.Forms.Panel
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents cboename As System.Windows.Forms.ComboBox
    Friend WithEvents Panel13 As System.Windows.Forms.Panel
    Friend WithEvents cboyear As System.Windows.Forms.ComboBox
    Friend WithEvents cbostream As System.Windows.Forms.ComboBox
    Friend WithEvents cboclass As System.Windows.Forms.ComboBox
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents dgvStudents As System.Windows.Forms.DataGridView
    Friend WithEvents StudentIDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StudentnumberDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StudentnameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents DataEntryPanel As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents bus As System.Windows.Forms.NumericUpDown
    Friend WithEvents agric As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents rel As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents geo As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents hist As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents sel_rel As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents phyc As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents chem As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents bio As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents mat As System.Windows.Forms.NumericUpDown
    Friend WithEvents eng As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents BtnExit As System.Windows.Forms.Button
    Friend WithEvents btnNewClass As System.Windows.Forms.Button
    Friend WithEvents txtsname As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtsnumber As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents comp As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboeid As System.Windows.Forms.ComboBox
    Friend WithEvents hsci As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents chkgensci As System.Windows.Forms.CheckBox
    Friend WithEvents gensci As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents artd As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtSnum As System.Windows.Forms.TextBox
    Friend WithEvents cboecode As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents chkkis As System.Windows.Forms.CheckBox
    Friend WithEvents ksl As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents kis As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtsid As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents txtEdit As System.Windows.Forms.CheckBox

End Class
